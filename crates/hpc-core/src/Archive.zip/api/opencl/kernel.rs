// src/api/kernel.rs

use opencl3::{
    kernel::Kernel as CLKernel,
    program::Program as CLProgram,
};

use crate::error::Result;
use super::Context;

//=============================================================================
// KERNEL
//=============================================================================

#[must_use]
#[derive(Debug)]
pub struct Kernel<'q> {
    inner: CLKernel,
    #[allow(dead_code)]
    program: CLProgram,
    _marker: std::marker::PhantomData<&'q ()>, // Kernel hängt an Context/Queue
}




impl<'q> Kernel<'q> {
    pub fn from_source(ctx: &Context, src: &str, name: &str) -> Result<Self> {
        let program = CLProgram::create_and_build_from_source(ctx.raw(), src, "")?;
        let inner = CLKernel::create(&program, name)?;
        Ok(Self {
            inner,
            program,
            _marker: std::marker::PhantomData,
        })
    }

    pub fn raw(&self) -> &CLKernel {
        &self.inner
    }


}
